GO687.COM — FINAL V6 SEO

Open index.html after extracting the full folder.

SEO pass included:
- stronger homepage positioning
- expanded trip-planning content
- country-specific Italy/Japan copy
- expanded FAQ content
- internal links
- improved image ALT text and lazy loading
- Organization, WebSite, FAQPage, SoftwareApplication and Breadcrumb structured data
- robots.txt and sitemap.xml
- unique titles and meta descriptions

FINAL ONLY — NOT DEPLOYED.
Store buttons currently display “Coming soon” until official App Store / Google Play URLs are available.


V7 FINAL QA PASS
- Page images optimized to WebP for faster mobile loading.
- Intrinsic image dimensions added to reduce layout shift.
- Mobile navigation accessibility improved (aria-expanded, Escape close, focus visibility).
- SEO titles and meta descriptions tightened.
- Reduced-motion support and extra small-screen rules added.
- LATER: replace “Coming soon” with the exact official App Store / Google Play URLs when available.
- IMPORTANT BEFORE DEPLOY: preserve/verify the existing go687.com support.html, privacy.html and terms.html pages because this preview package links to them but does not replace their legal content.
